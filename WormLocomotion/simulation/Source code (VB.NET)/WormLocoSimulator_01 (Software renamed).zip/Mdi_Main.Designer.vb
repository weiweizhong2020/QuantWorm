﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Mdi_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Mdi_Main))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Tool = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Tool_StartAnimation = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Tool_StopAnimation = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Window = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Window_ShowWorkspaceWindow = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Window_ShowOptionWindow = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip_Menu = New System.Windows.Forms.ToolStrip()
        Me.Cmd_Copy = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.Cmd_Run = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.Cmd_Stop = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.Cmd_WorkSpace = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip_Menu.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Tool, Me.Menu_Window, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(704, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Image = CType(resources.GetObject("Menu_File_Exit.Image"), System.Drawing.Image)
        Me.Menu_File_Exit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(92, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Tool
        '
        Me.Menu_Tool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Tool_StartAnimation, Me.Menu_Tool_StopAnimation})
        Me.Menu_Tool.Name = "Menu_Tool"
        Me.Menu_Tool.Size = New System.Drawing.Size(43, 20)
        Me.Menu_Tool.Text = "Tool"
        '
        'Menu_Tool_StartAnimation
        '
        Me.Menu_Tool_StartAnimation.Image = CType(resources.GetObject("Menu_Tool_StartAnimation.Image"), System.Drawing.Image)
        Me.Menu_Tool_StartAnimation.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Menu_Tool_StartAnimation.Name = "Menu_Tool_StartAnimation"
        Me.Menu_Tool_StartAnimation.Size = New System.Drawing.Size(155, 22)
        Me.Menu_Tool_StartAnimation.Text = "Start animation"
        '
        'Menu_Tool_StopAnimation
        '
        Me.Menu_Tool_StopAnimation.Image = CType(resources.GetObject("Menu_Tool_StopAnimation.Image"), System.Drawing.Image)
        Me.Menu_Tool_StopAnimation.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Menu_Tool_StopAnimation.Name = "Menu_Tool_StopAnimation"
        Me.Menu_Tool_StopAnimation.Size = New System.Drawing.Size(155, 22)
        Me.Menu_Tool_StopAnimation.Text = "Stop animation"
        '
        'Menu_Window
        '
        Me.Menu_Window.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Window_ShowWorkspaceWindow, Me.Menu_Window_ShowOptionWindow})
        Me.Menu_Window.Name = "Menu_Window"
        Me.Menu_Window.Size = New System.Drawing.Size(63, 20)
        Me.Menu_Window.Text = "Window"
        '
        'Menu_Window_ShowWorkspaceWindow
        '
        Me.Menu_Window_ShowWorkspaceWindow.Image = CType(resources.GetObject("Menu_Window_ShowWorkspaceWindow.Image"), System.Drawing.Image)
        Me.Menu_Window_ShowWorkspaceWindow.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Menu_Window_ShowWorkspaceWindow.Name = "Menu_Window_ShowWorkspaceWindow"
        Me.Menu_Window_ShowWorkspaceWindow.Size = New System.Drawing.Size(177, 22)
        Me.Menu_Window_ShowWorkspaceWindow.Text = "Workspace window"
        '
        'Menu_Window_ShowOptionWindow
        '
        Me.Menu_Window_ShowOptionWindow.Image = CType(resources.GetObject("Menu_Window_ShowOptionWindow.Image"), System.Drawing.Image)
        Me.Menu_Window_ShowOptionWindow.Name = "Menu_Window_ShowOptionWindow"
        Me.Menu_Window_ShowOptionWindow.Size = New System.Drawing.Size(177, 22)
        Me.Menu_Window_ShowOptionWindow.Text = "Option window"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip_Menu
        '
        Me.ToolStrip_Menu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Cmd_Copy, Me.ToolStripSeparator15, Me.Cmd_Run, Me.ToolStripSeparator6, Me.Cmd_Stop, Me.ToolStripSeparator1, Me.Cmd_WorkSpace, Me.ToolStripSeparator14})
        Me.ToolStrip_Menu.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip_Menu.Name = "ToolStrip_Menu"
        Me.ToolStrip_Menu.Size = New System.Drawing.Size(704, 25)
        Me.ToolStrip_Menu.TabIndex = 5
        Me.ToolStrip_Menu.Text = "ToolStrip1"
        '
        'Cmd_Copy
        '
        Me.Cmd_Copy.Image = CType(resources.GetObject("Cmd_Copy.Image"), System.Drawing.Image)
        Me.Cmd_Copy.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Cmd_Copy.Name = "Cmd_Copy"
        Me.Cmd_Copy.Size = New System.Drawing.Size(91, 22)
        Me.Cmd_Copy.Text = "Copy image"
        Me.Cmd_Copy.ToolTipText = "Copy (Ctrl+C)"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 25)
        '
        'Cmd_Run
        '
        Me.Cmd_Run.Image = CType(resources.GetObject("Cmd_Run.Image"), System.Drawing.Image)
        Me.Cmd_Run.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Cmd_Run.Name = "Cmd_Run"
        Me.Cmd_Run.Size = New System.Drawing.Size(105, 22)
        Me.Cmd_Run.Text = "Run animation"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'Cmd_Stop
        '
        Me.Cmd_Stop.Image = CType(resources.GetObject("Cmd_Stop.Image"), System.Drawing.Image)
        Me.Cmd_Stop.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Cmd_Stop.Name = "Cmd_Stop"
        Me.Cmd_Stop.Size = New System.Drawing.Size(108, 22)
        Me.Cmd_Stop.Text = "Stop animation"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'Cmd_WorkSpace
        '
        Me.Cmd_WorkSpace.Image = CType(resources.GetObject("Cmd_WorkSpace.Image"), System.Drawing.Image)
        Me.Cmd_WorkSpace.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Cmd_WorkSpace.Name = "Cmd_WorkSpace"
        Me.Cmd_WorkSpace.Size = New System.Drawing.Size(85, 22)
        Me.Cmd_WorkSpace.Text = "Workspace"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'Mdi_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(704, 478)
        Me.Controls.Add(Me.ToolStrip_Menu)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Mdi_Main"
        Me.Text = "WormLocoSimulator  v1.0 (Build 7)"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip_Menu.ResumeLayout(False)
        Me.ToolStrip_Menu.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tool As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tool_StartAnimation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tool_StopAnimation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Window As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Window_ShowWorkspaceWindow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip_Menu As System.Windows.Forms.ToolStrip
    Friend WithEvents Cmd_Copy As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Cmd_Run As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Cmd_WorkSpace As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Window_ShowOptionWindow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Cmd_Stop As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator

End Class
