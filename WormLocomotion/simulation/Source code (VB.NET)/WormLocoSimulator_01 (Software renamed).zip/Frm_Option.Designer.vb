﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Option
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Option))
        Me.Text_WormG1Count = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Text_WormLength = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Text_WormG2Count = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Text_WormG2Speed = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Text_WormG1Speed = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Text_WormWidth = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Text_PauseBTWFrame = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Text_EndFrame = New System.Windows.Forms.TextBox()
        Me.Text_StartFrame = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label_DestFolderError = New System.Windows.Forms.Label()
        Me.Check_SaveAsImages = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Text_DestFolder = New System.Windows.Forms.TextBox()
        Me.FolderDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.Cmd_SetNewFolder = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Text_WormG1Count
        '
        Me.Text_WormG1Count.Location = New System.Drawing.Point(98, 29)
        Me.Text_WormG1Count.Name = "Text_WormG1Count"
        Me.Text_WormG1Count.Size = New System.Drawing.Size(45, 20)
        Me.Text_WormG1Count.TabIndex = 0
        Me.Text_WormG1Count.Text = "1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Count"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Length"
        '
        'Text_WormLength
        '
        Me.Text_WormLength.Location = New System.Drawing.Point(57, 30)
        Me.Text_WormLength.Name = "Text_WormLength"
        Me.Text_WormLength.Size = New System.Drawing.Size(45, 20)
        Me.Text_WormLength.TabIndex = 3
        Me.Text_WormLength.Text = "50"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GroupBox4)
        Me.GroupBox1.Controls.Add(Me.GroupBox5)
        Me.GroupBox1.Controls.Add(Me.Text_WormWidth)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Text_WormLength)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 19)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(483, 147)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Worm parameters"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Text_WormG2Count)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.Text_WormG2Speed)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Location = New System.Drawing.Point(303, 30)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(164, 100)
        Me.GroupBox4.TabIndex = 9
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Worm Group 2"
        '
        'Text_WormG2Count
        '
        Me.Text_WormG2Count.Location = New System.Drawing.Point(98, 29)
        Me.Text_WormG2Count.Name = "Text_WormG2Count"
        Me.Text_WormG2Count.Size = New System.Drawing.Size(45, 20)
        Me.Text_WormG2Count.TabIndex = 0
        Me.Text_WormG2Count.Text = "1"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(19, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Count"
        '
        'Text_WormG2Speed
        '
        Me.Text_WormG2Speed.Location = New System.Drawing.Point(98, 56)
        Me.Text_WormG2Speed.Name = "Text_WormG2Speed"
        Me.Text_WormG2Speed.Size = New System.Drawing.Size(45, 20)
        Me.Text_WormG2Speed.TabIndex = 7
        Me.Text_WormG2Speed.Text = "0.5"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(19, 59)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(38, 13)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Speed"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Text_WormG1Count)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Controls.Add(Me.Text_WormG1Speed)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Location = New System.Drawing.Point(123, 31)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(164, 100)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Worm Group 1"
        '
        'Text_WormG1Speed
        '
        Me.Text_WormG1Speed.Location = New System.Drawing.Point(98, 56)
        Me.Text_WormG1Speed.Name = "Text_WormG1Speed"
        Me.Text_WormG1Speed.Size = New System.Drawing.Size(45, 20)
        Me.Text_WormG1Speed.TabIndex = 7
        Me.Text_WormG1Speed.Text = "1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Speed"
        '
        'Text_WormWidth
        '
        Me.Text_WormWidth.Location = New System.Drawing.Point(57, 56)
        Me.Text_WormWidth.Name = "Text_WormWidth"
        Me.Text_WormWidth.Size = New System.Drawing.Size(45, 20)
        Me.Text_WormWidth.TabIndex = 5
        Me.Text_WormWidth.Text = "5"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Width"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Text_PauseBTWFrame)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Text_EndFrame)
        Me.GroupBox2.Controls.Add(Me.Text_StartFrame)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 193)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(186, 158)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Animation"
        '
        'Text_PauseBTWFrame
        '
        Me.Text_PauseBTWFrame.Location = New System.Drawing.Point(119, 104)
        Me.Text_PauseBTWFrame.Name = "Text_PauseBTWFrame"
        Me.Text_PauseBTWFrame.Size = New System.Drawing.Size(51, 20)
        Me.Text_PauseBTWFrame.TabIndex = 5
        Me.Text_PauseBTWFrame.Text = "10"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 107)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(91, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Pause btw frames"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 29)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 13)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Start frame"
        '
        'Text_EndFrame
        '
        Me.Text_EndFrame.Location = New System.Drawing.Point(119, 67)
        Me.Text_EndFrame.Name = "Text_EndFrame"
        Me.Text_EndFrame.Size = New System.Drawing.Size(51, 20)
        Me.Text_EndFrame.TabIndex = 3
        Me.Text_EndFrame.Text = "710"
        '
        'Text_StartFrame
        '
        Me.Text_StartFrame.Location = New System.Drawing.Point(119, 26)
        Me.Text_StartFrame.Name = "Text_StartFrame"
        Me.Text_StartFrame.Size = New System.Drawing.Size(51, 20)
        Me.Text_StartFrame.TabIndex = 0
        Me.Text_StartFrame.Text = "500"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(11, 70)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "End frame"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Cmd_SetNewFolder)
        Me.GroupBox3.Controls.Add(Me.Label_DestFolderError)
        Me.GroupBox3.Controls.Add(Me.Check_SaveAsImages)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Text_DestFolder)
        Me.GroupBox3.Location = New System.Drawing.Point(213, 193)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(282, 158)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Save"
        '
        'Label_DestFolderError
        '
        Me.Label_DestFolderError.AutoSize = True
        Me.Label_DestFolderError.ForeColor = System.Drawing.Color.Red
        Me.Label_DestFolderError.Location = New System.Drawing.Point(17, 146)
        Me.Label_DestFolderError.Name = "Label_DestFolderError"
        Me.Label_DestFolderError.Size = New System.Drawing.Size(39, 13)
        Me.Label_DestFolderError.TabIndex = 3
        Me.Label_DestFolderError.Text = "Label5"
        '
        'Check_SaveAsImages
        '
        Me.Check_SaveAsImages.AutoSize = True
        Me.Check_SaveAsImages.Location = New System.Drawing.Point(17, 25)
        Me.Check_SaveAsImages.Name = "Check_SaveAsImages"
        Me.Check_SaveAsImages.Size = New System.Drawing.Size(133, 17)
        Me.Check_SaveAsImages.TabIndex = 2
        Me.Check_SaveAsImages.Text = "Save frames to images"
        Me.Check_SaveAsImages.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(89, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Destination folder"
        '
        'Text_DestFolder
        '
        Me.Text_DestFolder.Location = New System.Drawing.Point(17, 80)
        Me.Text_DestFolder.Multiline = True
        Me.Text_DestFolder.Name = "Text_DestFolder"
        Me.Text_DestFolder.Size = New System.Drawing.Size(249, 60)
        Me.Text_DestFolder.TabIndex = 0
        '
        'Cmd_SetNewFolder
        '
        Me.Cmd_SetNewFolder.Image = CType(resources.GetObject("Cmd_SetNewFolder.Image"), System.Drawing.Image)
        Me.Cmd_SetNewFolder.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Cmd_SetNewFolder.Location = New System.Drawing.Point(212, 49)
        Me.Cmd_SetNewFolder.Name = "Cmd_SetNewFolder"
        Me.Cmd_SetNewFolder.Size = New System.Drawing.Size(54, 24)
        Me.Cmd_SetNewFolder.TabIndex = 9
        Me.Cmd_SetNewFolder.Text = "     Set"
        Me.Cmd_SetNewFolder.UseVisualStyleBackColor = True
        '
        'Frm_Option
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 361)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frm_Option"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Options"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Text_WormG1Count As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Text_WormLength As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Text_WormG1Speed As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Text_WormWidth As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Text_PauseBTWFrame As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Text_EndFrame As System.Windows.Forms.TextBox
    Friend WithEvents Text_StartFrame As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Check_SaveAsImages As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Text_DestFolder As System.Windows.Forms.TextBox
    Friend WithEvents Label_DestFolderError As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Text_WormG2Count As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Text_WormG2Speed As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Cmd_SetNewFolder As System.Windows.Forms.Button
    Friend WithEvents FolderDialog As System.Windows.Forms.FolderBrowserDialog
End Class
