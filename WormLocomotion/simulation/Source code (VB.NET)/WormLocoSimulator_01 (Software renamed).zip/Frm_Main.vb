﻿Public Class Frm_Workspace


    Private Sub Me_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        e.Cancel = True
        Me.Hide()
    End Sub


    Private Sub Pic_Workspace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pic_Workspace.Click

    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.MdiParent = WormLocoSimulator.Mdi_Main
        WormLocoSimulator.Mdi_Main.Show()
    End Sub
End Class