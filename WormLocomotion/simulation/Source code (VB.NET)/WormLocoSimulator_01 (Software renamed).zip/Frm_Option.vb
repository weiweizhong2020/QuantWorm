﻿Public Class Frm_Option

    Private Sub Frm_Option_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label_DestFolderError.Visible = False
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        Me.MdiParent = WormLocoSimulator.Mdi_Main
        WormLocoSimulator.Mdi_Main.Show()
    End Sub

    Private Sub Cmd_SetNewFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_SetNewFolder.Click
        If FolderDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Text_DestFolder.Text = FolderDialog.SelectedPath
        End If
    End Sub
End Class