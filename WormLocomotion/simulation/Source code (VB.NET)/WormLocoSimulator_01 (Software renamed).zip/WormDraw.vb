﻿Imports System.Math
Imports System.Collections.Generic


Public Class WormDraw

    Public Property DefaultAngleStep As Double = 0.2
    Public Property WormLength As Double = 60
    Public Property SinDepth As Double = 10
    Public Property WormWidth As Double = 7
    Public Property WormCountIndex As Integer = 7
    Public Property WormUnitLengthMax As Integer = 500


    Public WormUnitLocation(,) As PointF
    Public WormUnitSize(,) As Double
    Public WormSinPhase() As Double
    Public WormMovementVector() As PointF
    Public WormSpeed() As Double



    Public Sub InitializeWorms()


        ReDim WormUnitLocation(WormCountIndex, WormUnitLengthMax)
        ReDim WormUnitSize(WormCountIndex, WormUnitLengthMax)
        ReDim WormSinPhase(WormCountIndex)
        ReDim WormMovementVector(WormCountIndex)
        ReDim WormSpeed(WormCountIndex)


        Randomize()


        For w As Integer = 0 To WormCountIndex
            WormUnitLocation(w, 0) = New PointF(Rnd(1) * 300 + 100,
                                                 Rnd(1) * 350 + 50)

            For q As Integer = 1 To WormUnitLengthMax
                WormUnitLocation(w, q) = WormUnitLocation(w, 0)
            Next


            WormSinPhase(w) = Rnd(1) * Math.PI * 2
        Next
    End Sub

    Public Sub Calculated_AdjustedWormMovementVector()
        For w As Integer = 0 To WormCountIndex

            Dim Theta As Double
            Theta = Rnd(1) * Math.PI * 2
            WormMovementVector(w) = New PointF(CSng(Sin(Theta)), CSng(Cos(Theta)))

            WormMovementVector(w).X = CSng(WormMovementVector(w).X * WormSpeed(w))
            WormMovementVector(w).Y = CSng(WormMovementVector(w).Y * WormSpeed(w))
        Next
    End Sub


    Public Sub InitializeWormsWithParameters(ByVal Ini_WormCountIndex As Integer,
                               ByVal Ini_WormLength As Double,
                               ByVal Ini_WormWidth As Double)

        WormCountIndex = Ini_WormCountIndex

        WormLength = Ini_WormLength
        WormWidth = Ini_WormWidth

        Call InitializeWorms()
    End Sub



    Public Sub MoveOneStep()
        Dim TangentLinePoint1, TangentLinePoint2 As PointF
       
        Dim SpeedAdjustment As Double


        For w As Integer = 0 To WormUnitLocation.GetUpperBound(0)


            For q As Integer = WormUnitLocation.GetUpperBound(1) To 1 Step -1
                WormUnitLocation(w, q).X = WormUnitLocation(w, q - 1).X
                WormUnitLocation(w, q).Y = WormUnitLocation(w, q - 1).Y
            Next

            SpeedAdjustment = Math.Sqrt(WormMovementVector(w).X ^ 2 + WormMovementVector(w).Y ^ 2)

            WormSinPhase(w) = WormSinPhase(w) + DefaultAngleStep * SpeedAdjustment
            If WormSinPhase(w) > Math.PI * 2 Then
                WormSinPhase(w) -= Math.PI * 2
            End If



            Call Get_TangentLinePoints(WormUnitLocation(w, 1),
                                                        WormMovementVector(w), SinDepth,
                                                        TangentLinePoint1,
                                                        TangentLinePoint2)



            WormUnitLocation(w, 1) = Get_InnnetPointInLine(
                            TangentLinePoint1, TangentLinePoint2,
                            CSng(Sin(WormSinPhase(w)) * SinDepth / 2 + SinDepth / 2))



  
        Next

    End Sub



    Public Function DrawWorm() As Bitmap

        Dim LengthLimit As Integer
        Dim LengthSum As Double


        Using bm As New Bitmap(640, 480),
                GraphBox As Graphics = Graphics.FromImage(bm),
                myPen As New Pen(Color.Black)

            myPen.Color = Color.Black

            GraphBox.Clear(Color.White)

            For w As Integer = 0 To WormUnitLocation.GetUpperBound(0)
                'Check worm length
                LengthSum = 0
                LengthLimit = WormUnitLocation.GetUpperBound(1) - 1
                For q As Integer = 1 To WormUnitLocation.GetUpperBound(1) - 1
                    LengthSum = LengthSum + Distance(WormUnitLocation(w, q).X, WormUnitLocation(w, q).Y,
                                    WormUnitLocation(w, q + 1).X, WormUnitLocation(w, q + 1).Y)
                    If LengthSum > WormLength Then
                        LengthLimit = q
                        Exit For
                    End If
                Next


                'Set worm width
                For q As Integer = 1 To LengthLimit
                    WormUnitSize(w, q) = WormWidth
                Next



                'Adjust head, tail width based on speed
                Dim SpeedAdjustment As Double =
                            Math.Sqrt(WormMovementVector(w).X ^ 2 + WormMovementVector(w).Y ^ 2)
                Dim MaxHeadLength As Integer =
                            CInt(0.5 / SpeedAdjustment * 18)
                For q As Integer = 0 To MaxHeadLength
                    WormUnitSize(w, q + 1) = WormWidth * (0.5 + q / MaxHeadLength * 0.5)
                    WormUnitSize(w, LengthLimit - q) = WormUnitSize(w, q + 1)
                Next



                'Draw worm
                For q As Integer = 1 To LengthLimit
                    GraphBox.FillEllipse(Brushes.Black, New Rectangle(
                                        CInt(WormUnitLocation(w, q).X - WormUnitSize(w, q) / 2),
                                        CInt(WormUnitLocation(w, q).Y - WormUnitSize(w, q) / 2),
                                        CInt(WormUnitSize(w, q)), CInt(WormUnitSize(w, q)))
                                        )
                Next

            Next

            DrawWorm = CType(bm.Clone, Bitmap)

        End Using

    End Function


    Public Sub Get_TangentLinePoints(ByVal CenterPoint As PointF,
                            ByVal VectorPoint As PointF,
                            ByVal TangentLineLength As Double,
                            ByRef Return_Point1 As PointF, ByRef Return_Point2 As PointF)

        Dim S1A_X, S1A_Y, S1B_X, S1B_Y As Double
        Dim S1S2Angle As Double

        S1S2Angle = Atan2(VectorPoint.X, VectorPoint.Y)

        S1A_X = CenterPoint.X + Sin(S1S2Angle + 0.5 * Math.PI) * TangentLineLength / 2
        S1A_Y = CenterPoint.Y + Cos(S1S2Angle + 0.5 * Math.PI) * TangentLineLength / 2
        S1B_X = CenterPoint.X + Sin(S1S2Angle - 0.5 * Math.PI) * TangentLineLength / 2
        S1B_Y = CenterPoint.Y + Cos(S1S2Angle - 0.5 * Math.PI) * TangentLineLength / 2

        Return_Point1 = New PointF(CSng(S1A_X), CSng(S1A_Y))
        Return_Point2 = New PointF(CSng(S1B_X), CSng(S1B_Y))

    End Sub



    Public Function Get_InnnetPointInLine(ByVal Point1 As PointF, ByVal Point2 As PointF,
                                     ByVal PointLocation As Single) As PointF
        Dim InnerPoint As PointF
        Dim Max_Pixel As Single

        Max_Pixel = Distance(Point1.X, Point1.Y, Point2.X, Point2.Y)
        InnerPoint.X = (PointLocation * Point1.X +
                             (Max_Pixel - PointLocation) * Point2.X) / Max_Pixel
        InnerPoint.Y = (PointLocation * Point1.Y +
                               (Max_Pixel - PointLocation) * Point2.Y) / Max_Pixel
        Return InnerPoint
    End Function



    Public Function Distance(ByVal X1 As Single, ByVal Y1 As Single, ByVal X2 As Single, ByVal Y2 As Single) As Single
        Dim R As Single

        R = CSng(Math.Sqrt((X2 - X1) ^ 2 + (Y2 - Y1) ^ 2))

        Return R
    End Function


    Public Function Generate_Canvas(ByVal nWidth As Integer,
                     ByVal nHeight As Integer, ByVal BackColor As Color) As Bitmap


        Using bm As New Bitmap(nWidth, nHeight),
             GraphBox As Graphics = Graphics.FromImage(bm),
             myPen As New Pen(Color.Black)

            Call GraphBox.Clear(BackColor)

            Generate_Canvas = CType(bm.Clone, Bitmap)
        End Using


    End Function


    Public Sub Check_ReachingBoundary()

        For q As Integer = 0 To WormCountIndex
            WormUnitLocation(q, 0).X += WormMovementVector(q).X
            WormUnitLocation(q, 0).Y += WormMovementVector(q).Y

            If WormUnitLocation(q, 0).X < 0 Or WormUnitLocation(q, 0).X > 640 Then
                WormMovementVector(q).X = -WormMovementVector(q).X
            End If

            If WormUnitLocation(q, 0).Y < 0 Or WormUnitLocation(q, 0).Y > 480 Then
                WormMovementVector(q).Y = -WormMovementVector(q).Y
            End If

        Next
    End Sub


    Public Function FolderExists(ByVal FolderPath As String) As Boolean

        If FolderPath = "" Then Return False

        Dim f As New IO.DirectoryInfo(FolderPath)
        Return f.Exists

    End Function
End Class
