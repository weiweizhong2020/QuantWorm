﻿Imports System.Math
Imports System.Collections.Generic
Imports System.IO


Public Class Mdi_Main

    Public WithEvents myWormDraw As New WormDraw
    Public IsStopAnimation As Boolean = False


    Private Sub Me_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        End
    End Sub


    Private Sub Mdi_Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        System.Threading.Thread.CurrentThread.CurrentCulture =
                        New System.Globalization.CultureInfo("en-US", True)



        With Frm_Workspace
            .Left = 0
            .Top = 0
            .Show()
        End With


        With Frm_Option
            .Left = Frm_Workspace.Width + 2
            .Top = 0
            .Show()
        End With
    End Sub

    Private Sub Menu_Window_ShowWorkspaceWindow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Window_ShowWorkspaceWindow.Click
        Frm_Workspace.Show()
    End Sub

    Private Sub Menu_File_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_File_Exit.Click
        End
    End Sub

    Private Sub Menu_About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_About.Click
        MsgBox("WormLocoSimulator" + vbCrLf +
               "(C) SangKyu Jung in Zhong Lab (http://wormlab.rice.edu/)",
               MsgBoxStyle.Information, "About")

    End Sub

    Private Sub Menu_Tool_StartAnimation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Tool_StartAnimation.Click
        With Frm_Workspace
            .Pic_Workspace.Image = myWormDraw.Generate_Canvas(640, 480, Color.White)
            .Focus()
        End With

        Application.DoEvents()


        Menu_Tool_StartAnimation.Enabled = False
        Cmd_Run.Enabled = False


        Dim ImageCount As Integer = 0
        Dim StartFrame, EndFrame As Integer
        Dim TimePauseBTWFrame As Integer
        Dim DestFolder As String = ""
        Dim WormG1Count, WormG2Count As Integer
        Dim WormG1Speed, WormG2Speed As Double

        Try
            WormG1Count = CInt(Frm_Option.Text_WormG1Count.Text)
        Catch ex As Exception
        End Try

        Try
            WormG2Count = CInt(Frm_Option.Text_WormG2Count.Text)
        Catch ex As Exception
        End Try

        Try
            WormG1Speed = CSng(Frm_Option.Text_WormG1Speed.Text)
        Catch ex As Exception
        End Try

        Try
            WormG2Speed = CSng(Frm_Option.Text_WormG2Speed.Text)
        Catch ex As Exception
        End Try

        Try
            myWormDraw.WormLength = CSng(Frm_Option.Text_WormLength.Text)
        Catch ex As Exception
        End Try

        Try
            myWormDraw.WormWidth = CSng(Frm_Option.Text_WormWidth.Text)
        Catch ex As Exception
        End Try

        Try
            StartFrame = CInt(Frm_Option.Text_StartFrame.Text)
        Catch ex As Exception
        End Try

        Try
            EndFrame = CInt(Frm_Option.Text_EndFrame.Text)
        Catch ex As Exception
        End Try

        Try
            TimePauseBTWFrame = CInt(Frm_Option.Text_PauseBTWFrame.Text)
        Catch ex As Exception
        End Try


        myWormDraw.WormCountIndex = WormG1Count + WormG2Count - 1
        myWormDraw.InitializeWorms()



        'Set destination folder
        If Frm_Option.Check_SaveAsImages.Checked Then
            If myWormDraw.FolderExists(Frm_Option.Text_DestFolder.Text) Then
                DestFolder = Frm_Option.Text_DestFolder.Text
                Frm_Option.Label_DestFolderError.Visible = False
            Else
                DestFolder = ""
                Frm_Option.Label_DestFolderError.Text = "Path not found!"
                Frm_Option.Label_DestFolderError.Visible = True
            End If
        End If




        'Set individual worm speed
        For q As Integer = 0 To WormG1Count - 1
            myWormDraw.WormSpeed(q) = WormG1Speed
        Next
        For q As Integer = WormG1Count To myWormDraw.WormCountIndex
            myWormDraw.WormSpeed(q) = WormG2Speed
        Next
        myWormDraw.Calculated_AdjustedWormMovementVector()




        IsStopAnimation = False
        Do
            With Frm_Workspace

                myWormDraw.Check_ReachingBoundary()



                If ImageCount > StartFrame Then
                    myWormDraw.MoveOneStep()
                    .Pic_Workspace.Image = myWormDraw.DrawWorm()


                    If Frm_Option.Check_SaveAsImages.Checked And DestFolder <> "" Then
                        Try

                            Frm_Workspace.Pic_Workspace.Image.Save(DestFolder + "\Frame" +
                                                                   Format(ImageCount, "00000") + ".gif")
                        Catch ex As Exception
                            Frm_Option.Label_DestFolderError.Visible = True
                            Frm_Option.Label_DestFolderError.Text = "Failed to save image files"
                        End Try


                    End If


                    System.Threading.Thread.Sleep(TimePauseBTWFrame)
                Else
                    myWormDraw.MoveOneStep()
                End If



                ImageCount += 1
                .Text = "Workspace   [Frame=" + ImageCount.ToString + "]"

                If ImageCount > EndFrame Then
                    Exit Do
                End If


                Application.DoEvents()
                If IsStopAnimation Then Exit Do
                Application.DoEvents()


                GC.Collect()

            End With
        Loop


        Menu_Tool_StartAnimation.Enabled = True
        Cmd_Run.Enabled = True
    End Sub

    Private Sub Cmd_WorkSpace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_WorkSpace.Click
        Frm_Workspace.Show()
    End Sub

    Private Sub Cmd_Copy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Copy.Click
        Try
            Clipboard.SetImage(Frm_Workspace.Pic_Workspace.Image)
        Catch ex As Exception
            MsgBox("Unable to copy image", MsgBoxStyle.Critical, "Copy")
        End Try
    End Sub

    Private Sub Cmd_Run_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Run.Click
        Call Menu_Tool_StartAnimation_Click("", Nothing)
    End Sub

    Private Sub Menu_Window_ShowOptionWindow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Window_ShowOptionWindow.Click
        Frm_Option.Show()
    End Sub

    Private Sub Menu_Tool_StopAnimation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Tool_StopAnimation.Click
        IsStopAnimation = True
        Menu_Tool_StartAnimation.Enabled = True
        Cmd_Run.Enabled = True
    End Sub

    Private Sub Cmd_Stop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Stop.Click
        Menu_Tool_StopAnimation_Click("", Nothing)
    End Sub


End Class
